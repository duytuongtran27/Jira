from typing import List, Optional, TypeVar, Union, Literal
import requests
from requests import Session
from requests.models import HTTPBasicAuth
from urllib3.exceptions import InsecureRequestWarning
import urllib3
from dataclasses import dataclass
from rdflib import Graph
import urllib
import logging
import json
import os
import re

from alm_ccm.base import QueryStatement
from .workitem import (
    Workitem,
    WORKITEM_TYPE_IDX,
    parse_workitem,
    parse_query_result,
    WorkitemsQueryResult,
    WorkitemProperty,
)

# Suppress the warnings from urllib3
urllib3.disable_warnings(category=InsecureRequestWarning)

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=Workitem)

# -------------- Tracking tool integration ---------------------
try:
    user_id = os.getlogin()
except Exception:
    user_id = "unknown"

TRACKING_TOOL_URL = "https://sgpvmc0521.apac.bosch.com:8443/portal/api/tracking/save"
TRACKING_TOOL_PARAMS = {
    "toolId": "BGSV_Building_Blocks",
    "userId": user_id,
    "functionName": "Building_Block_ALM_CCM",
}


# def send_request(url: str, params: dict[str, str]):
#     logger.debug(
#         "send request to tracking tool at `{}` with params=`{}`".format(url, params)
#     )
#     try:
#         res = requests.get(url, params=params, verify=False)
#         if res.status_code != 200:
#             logger.warning(
#                 "Failed to send request to tracking tool. Error code: `{}`. Response: `{}`".format(
#                     res.status_code, res.text
#                 )
#             )
#     except Exception:
#         pass


# send_request(TRACKING_TOOL_URL, TRACKING_TOOL_PARAMS)
# ---------------------------------------------------------


@dataclass
class Project:
    title: str
    area: str


class Client(object):
    """
    An ALM CCM client.
    """

    def __init__(self, base_url: str, username: str, password: str):
        """Initialize a client

        Args:
            base_url (str): ALM server base url (without the `/ccm` part)
            username (str): ALM username
            password (str): ALM password
        """
        self.base_url = base_url
        self.session = Session()
        self.session.verify = False
        self.session.auth = HTTPBasicAuth(username, password)
        self.session.headers.update({"OSLC-Core-Version": "2.0"})

    def get_all_projects(self) -> List[Project]:
        """Get info (title and project-area) of all projects

        Returns:
            List[Project]: List of project infos
        """
        url = urllib.parse.urljoin(self.base_url, "ccm/oslc/workitems/catalog")
        res = self.session.get(url, headers={"Accept": "application/rdf+xml"})
        if res.status_code >= 400:
            logger.error(res.text)
        res.raise_for_status()
        g = Graph()
        g.parse(data=res.content, format="xml")
        g.bind("dcterms", "http://purl.org/dc/terms/")
        g.bind("oslc", "http://open-services.net/ns/core#")
        rows = g.query("""
                             SELECT ?title ?url
                             WHERE {
                                 ?s dcterms:title ?title .
                                 ?s oslc:details ?url .
                             }
                         """)
        projects = []
        for row in rows:
            title = str(row.title)
            url = str(row.url)
            last_slash = url.rfind("/")
            area = url[last_slash + 1 :]
            projects.append(Project(title=title, area=area))
        return projects


class ProjectClient(object):
    """
    An ALM CCM project client which performs operations in a specific project.
    """

    def __init__(
        self,
        project_area: str,
        client: Optional[Client] = None,
        base_url: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ):
        """Initialize a project client.

        Args:
            project_area (str): project area
            client (Optional[Client], optional): a Client object, this is not required if `base_url`, `username` and `password` are provided. Defaults to None.
            base_url (Optional[str], optional): ALM base url (without `/ccm` part). This is not required if `client` is provided. Defaults to None.
            username (Optional[str], optional): ALM username. This is not required if `client` is provided. Defaults to None.
            password (Optional[str], optional): ALM password. This is not required if `client` is provided. Defaults to None.
        """
        if client is not None:
            self.session = client.session
            self.base_url = client.base_url
        else:
            assert base_url is not None
            assert username is not None
            assert password is not None
            self.base_url = base_url
            self.session = Session()
            self.session.verify = False
            self.session.auth = HTTPBasicAuth(username, password)
        self.session.headers.update(
            {"Accept": "application/json", "OSLC-Core-Version": "2.0"}
        )
        self.area = project_area

    def query_workitems(
        self,
        where: Optional[Union[QueryStatement, str]] = None,
        select: Union[List[Union[WorkitemProperty, str]], Literal["*"]] = [],
        paging: Optional[bool] = None,
        page_size: Optional[int] = None,
        search_terms: List[str] = [],
    ) -> WorkitemsQueryResult:
        """Query workitems.

        Args:
            where (Optional[Union[QueryStatement, str]], optional): the query criterias, if this is None, it matches all workitems on the system. Defaults to None.
            select (Union[List[Union[WorkitemProperty, str]], Literal[, optional): select which properties to be populated, "*" to select all. Defaults to [].
            paging (Optional[bool], optional): enable pagination if `True`. Defaults to None.
            page_size (Optional[int], optional): configure how many results per page. Defaults to None.
            search_terms (List[str]): search terms for full-text search on text values of workitems. Default to [].

        Returns:
            WorkitemsQueryResult: the first result page of the query
        """
        url = urllib.parse.urljoin(
            self.base_url, f"ccm/oslc/contexts/{self.area}/workitems"
        )
        # preprocess select
        if select == "*":
            final_select = "*"
        else:
            select_list = [str(x) for x in select]
            if "dcterms:type" not in select_list:
                select_list.append("dcterms:type")
            final_select = ",".join(str(x) for x in select_list)

        # preprocess search terms
        if len(search_terms) == 0:
            final_search_terms = None
        else:
            final_search_terms = ",".join([f'"{s}"' for s in search_terms])

        res = self.session.get(
            url,
            params={
                "oslc.select": final_select,
                "oslc.where": str(where) if where is not None else None,
                "oslc.paging": paging,
                "oslc.pageSize": page_size,
                "oslc.searchTerms": final_search_terms,
            },
        )
        if res.status_code >= 400:
            logger.error(res.text)
        res.raise_for_status()
        return parse_query_result(json.loads(res.content))

    def get_query_page(
        self, query_result: WorkitemsQueryResult, start_index: int
    ) -> Optional[WorkitemsQueryResult]:
        """Return a page of query result

        Args:
            query_result (WorkitemsQueryResult): a query result
            start_index (int): the start index of the results. Please note that this is not the index of the page.\
                               For example with a query that has page_size=10, if start_index=15, this interface\
                               will return the 16th to 25th result.

        Returns:
            Optional[WorkitemsQueryResult]: the query result page. ``None`` if the query_result object does not have a next_page or if index is out of range.
        """
        if query_result.next_page is None:
            return None
        url = re.sub(
            r"_startIndex=\d+",
            "_startIndex={}".format(start_index),
            query_result.next_page,
        )
        res = self.session.get(url)
        if (
            res.status_code == 500
            and res.text is not None
            and "startIndex is out of range" in res.text
        ):
            return None
        if res.status_code >= 400:
            logger.error(res.text)
        res.raise_for_status()
        return parse_query_result(json.loads(res.content))

    def next_page(
        self, query_result: WorkitemsQueryResult
    ) -> Optional[WorkitemsQueryResult]:
        """Get next page of a query.

        Args:
            query_result (WorkitemsQueryResult): the query result page

        Returns:
            Optional[WorkitemsQueryResult]: the next result page. `None` if the provided page is the last.
        """
        if query_result.next_page is None:
            return None
        res = self.session.get(query_result.next_page)
        if res.status_code >= 400:
            logger.error(res.text)
        res.raise_for_status()
        return parse_query_result(json.loads(res.content))

    def modify_workitem(
        self,
        workitem: T,
        id: Optional[Union[str, int]] = None,
        uri: Optional[str] = None,
    ) -> T:
        """Modify workitem.

        Args:
            workitem (T): the workitem to modify.
            id (Optional[Union[str, int]], optional): the workitem id. Not required if `uri` is provided. Defaults to None.
            uri (Optional[str], optional): the workitem uri. Not required if `id` is provided. Defaults to None.

        Returns:
            T: the modified workitem.
        """
        assert (id is not None) or (uri is not None)

        if id is not None:
            url = urllib.parse.urljoin(
                self.base_url,
                "ccm/resource/itemName/com.ibm.team.workitem.WorkItem/" + str(id),
            )
        else:
            url = uri

        res = self.session.put(
            url,
            data=workitem.model_dump_json(exclude_unset=True, by_alias=True),
            headers={"Content-Type": "application/json"},
        )
        if res.status_code >= 400:
            logger.error(res.text)
        res.raise_for_status()
        return parse_workitem(json.loads(res.content))

    def get_workitem(
        self, id: Optional[Union[str, int]] = None, uri: Optional[str] = None
    ) -> Workitem:
        """Get info of a workitem.

        Args:
            id (Optional[Union[str, int]], optional): the workitem id. Not required if `uri` is provided. Defaults to None.
            uri (Optional[str], optional): the workitem uri. Not required if `id` is provided. Defaults to None.

        Returns:
            Workitem: the workitem info.
        """
        assert (id is not None) or (uri is not None)
        if id is not None:
            url = urllib.parse.urljoin(
                self.base_url,
                "ccm/resource/itemName/com.ibm.team.workitem.WorkItem/" + str(id),
            )
        else:
            url = uri

        res = self.session.get(url)
        if res.status_code >= 400:
            logger.error(res.text)
        res.raise_for_status()
        return parse_workitem(json.loads(res.content))

    def delete_workitem(
        self,
        workitem: Optional[Workitem] = None,
        id: Optional[Union[str, int]] = None,
        uri: Optional[str] = None,
    ):
        """Delete a workitem.

        Args:
            workitem (Optional[Workitem], optional): the workitem object (with uri populated). Not required if either `id` or `uri` is provided. Defaults to None.
            id (Optional[Union[str, int]], optional): the workitem id. Not required if either `workitem` or `uri` is provided. Defaults to None.
            uri (Optional[str], optional): the workitem uri. Not required if either `workitem` or `id` is provided. Defaults to None.
        """
        assert (workitem is not None) or (id is not None) or (uri is not None)
        if id is not None:
            url = urllib.parse.urljoin(
                self.base_url,
                "ccm/resource/itemName/com.ibm.team.workitem.WorkItem/" + str(id),
            )
        elif uri is not None:
            url = uri
        else:
            url = workitem.uri
        # prevent ALM CCM from misunderstanding that this request is an CSRF attack by sending a special header
        session_id = self.session.cookies.get("JSESSIONID")
        res = self.session.delete(url, headers={"X-Jazz-CSRF-Prevent": session_id})
        if res.status_code >= 400:
            logger.error(res.text)
        res.raise_for_status()

    def create_workitem(self, workitem: T) -> T:
        """Create a workitem.

        Args:
            workitem (T): the workitem changeset.

        Returns:
            T: the newly created workitem.
        """
        workitem.dcterms__type = WORKITEM_TYPE_IDX[workitem.__class__]

        url = urllib.parse.urljoin(
            self.base_url, f"ccm/oslc/contexts/{self.area}/workitems"
        )
        res = self.session.post(
            url,
            headers={"Content-Type": "application/json"},
            data=workitem.model_dump_json(exclude_unset=True, by_alias=True),
        )
        if res.status_code >= 400:
            logger.error(res.text)
        res.raise_for_status()
        created_workitem = parse_workitem(json.loads(res.content))
        created_workitem.uri = urllib.parse.urljoin(
            self.base_url,
            "ccm/resource/itemName/com.ibm.team.workitem.WorkItem/"
            + str(created_workitem.identifier),
        )
        return created_workitem
